package com.fiscaliageneralags.fiscalia.IInteractors;

import com.fiscaliageneralags.fiscalia.Models.PreDenuncia;


/**
 * Created by ERodriguezF on 22/01/2018.
 * @author ERodriguezF
 * @version 1.18
 */

public interface IPreDenunciaInteractor {
    void postPreDenuncia(PreDenuncia newPreDenuncia);
}
