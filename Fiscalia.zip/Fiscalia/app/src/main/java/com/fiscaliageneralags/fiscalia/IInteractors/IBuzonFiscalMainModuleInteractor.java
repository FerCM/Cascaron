package com.fiscaliageneralags.fiscalia.IInteractors;

import com.fiscaliageneralags.fiscalia.Models.SugerenciaAlFiscal;

/**
 * Created by ERodriguezF on 22/01/2018.
 * @author ERodriguezF
 * @version 1.18
 */

public interface IBuzonFiscalMainModuleInteractor {

    void postSugerenciaAlFiscal(SugerenciaAlFiscal sugerenciaAlFiscal);

}
