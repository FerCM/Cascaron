package com.fiscaliageneralags.fiscalia.Utils;

/**
 * Created by ERodriguezF on 17/01/2018.
 * @author ERodriguezF
 * @version 1.18
 */

public class ValidationErrorCodes {
    /**
     * Email error Constant String
     */
    public static String EmailUniqueError = "EMAIL_ERROR";

    /**
     * CURP error Constant String
     */
    public static String CURPUniqueError = "CURP_ERROR";
}
