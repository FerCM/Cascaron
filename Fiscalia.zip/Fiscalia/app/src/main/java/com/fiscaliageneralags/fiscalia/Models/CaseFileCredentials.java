package com.fiscaliageneralags.fiscalia.Models;

/**
 * Created by ERodriguezF on 09/03/2018.
 * @author ERodriguezF
 * @version 1.18
 */

public class CaseFileCredentials {

    public String caseFileCode;
    public String passGuid;

}
