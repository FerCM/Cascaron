package com.fiscaliageneralags.fiscalia.Utils.Interfaces;

/**
 * Created by ERodriguezF on 18/12/2017.
 * @author ERodriguezF
 * @version 1.18
 */

public interface INavegable {

    void makeFragmentTransactionTo(int moduleID);

}
