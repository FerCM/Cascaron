package com.fiscaliageneralags.fiscalia.Utils.Interfaces;

/**
 * Created by ERodriguezF on 24/01/2018.
 * @author ERodriguezF
 * @version 1.18
 */

public interface IConnectionErrorHandler {
    void HandelConecctionError();
}
