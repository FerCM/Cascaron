package com.fiscaliageneralags.fiscalia.Utils.Interfaces;

import android.content.Context;

import com.fiscaliageneralags.fiscalia.Models.QuejaItem;


/**
 * Created by ERodriguezF on 03/01/2018.
 * @author ERodriguezF
 * @version 1.18
 */

public interface IQuejaOnClickListener {
    void onClick(Context context, QuejaItem item);
}
