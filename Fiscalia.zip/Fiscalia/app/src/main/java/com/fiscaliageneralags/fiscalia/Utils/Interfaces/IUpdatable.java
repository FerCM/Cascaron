package com.fiscaliageneralags.fiscalia.Utils.Interfaces;

/**
 * Created by ERodriguezF on 03/01/2018.
 * @author ERodriguezF
 * @version 1.18
 */

public interface IUpdatable {
    void UpdateContent();
}
