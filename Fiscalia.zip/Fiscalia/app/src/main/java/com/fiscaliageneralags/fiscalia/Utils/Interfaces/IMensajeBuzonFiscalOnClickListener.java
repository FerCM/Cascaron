package com.fiscaliageneralags.fiscalia.Utils.Interfaces;

import android.content.Context;

import com.fiscaliageneralags.fiscalia.Models.MensajeAlFiscalItem;

/**
 * Created by ERodriguezF on 28/12/2017.
 * @author ERodriguezF
 * @version 1.18
 */

public interface IMensajeBuzonFiscalOnClickListener {
    void onClick(Context context, MensajeAlFiscalItem item);
}
