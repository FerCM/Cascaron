package com.fiscaliageneralags.fiscalia.IInteractors;

/**
 * Created by ERodriguezF on 05/03/2018.
 * @author ERodriguezF
 * @version 1.18
 */

public interface IUbicacionAgenciasModulosParaDenunciaInteractor {

    //Services
    void getEdificiosParaDenunciar();
    void getMunicipios();
    void getTodasLasAgencias();
}
