package com.fiscaliageneralags.fiscalia.IInteractors;

/**
 * Created by ERodriguezF on 06/03/2018.
 * @author ERodriguezF
 * @version 1.18
 */

public interface IUbicacionAgenciaInvestigaMiExpedienteInteractor {

    //Services
    void getAgenciaIntegradoraDeExpediente(String numExpendiente, String password);

}
