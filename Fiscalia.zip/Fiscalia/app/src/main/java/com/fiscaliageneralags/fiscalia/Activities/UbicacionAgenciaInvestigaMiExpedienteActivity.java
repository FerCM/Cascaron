package com.fiscaliageneralags.fiscalia.Activities;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.transition.Fade;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.afollestad.materialdialogs.MaterialDialog;
import com.fiscaliageneralags.fiscalia.IPresenters.IUbicacionAgenciaInvestigaMiExpedientePresenter;
import com.fiscaliageneralags.fiscalia.IViews.IUbicacionAgenciaInvestigaMiExpedienteView;
import com.fiscaliageneralags.fiscalia.Models.AgenciaDeExpediente;
import com.fiscaliageneralags.fiscalia.Presenters.UbicacionAgenciaInvestigaMiExpedientePresenter;
import com.fiscaliageneralags.fiscalia.R;
import com.github.florent37.expansionpanel.ExpansionHeader;
import com.github.florent37.expansionpanel.ExpansionLayout;
import com.github.florent37.expansionpanel.viewgroup.ExpansionLayoutCollection;
import com.github.florent37.expansionpanel.viewgroup.ExpansionsViewGroupConstraintLayout;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by ERodriguezF on 21/12/2017.
 * @author ERodriguezF
 * @version 1.18
 */

public class UbicacionAgenciaInvestigaMiExpedienteActivity extends AppCompatActivity implements IUbicacionAgenciaInvestigaMiExpedienteView, OnMapReadyCallback, SearchView.OnQueryTextListener, GoogleMap.OnMarkerClickListener, GoogleMap.OnCameraMoveStartedListener, GoogleMap.OnMapClickListener {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.ubicacion_agencias_map_auto_text_view)
    SearchView mSearchItem;
    @BindView(R.id.ubiacion_agencias_location_description) LinearLayout agenciesInLocation;
    @BindView(R.id.agen_layout)
    ConstraintLayout agenciasContent;
    @BindView(R.id.expansion_view_group)
    ExpansionsViewGroupConstraintLayout expansionsViewGroupConstraintLayout;
    @BindView(R.id.rootConstLayout)
    ConstraintLayout rootLayout;

    private MaterialDialog processDialog;
    private Context context;
    private GoogleMap mMap;
    private UbicacionAgenciaInvestigaMiExpedienteActivity activity;
    private int indexColor = 1;
    private List<ExpansionHeader> expansionHeaders;
    private IUbicacionAgenciaInvestigaMiExpedientePresenter presenter;

    /**
     * Load initial configuration
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = this;
        setupWindowAnimations();
        setContentView(R.layout.activity_ubicacion_agencia_investiga_expediente);
        ButterKnife.bind(this);
        context = this;
        setSupportActionBar(toolbar);
        processDialog = new MaterialDialog.Builder(this)
                .content("Cargando, por favor espere.")
                .progress(true, 0)
                .build();
        processDialog.setCanceledOnTouchOutside(false);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.ubicacion_agencias_main_map_view);
        mapFragment.getMapAsync(this);
        presenter = new UbicacionAgenciaInvestigaMiExpedientePresenter(this,this);
        mSearchItem.setOnQueryTextListener(this);
        expansionHeaders = new ArrayList<ExpansionHeader>();
        rootLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                int heightDiff = rootLayout.getRootView().getHeight() - rootLayout.getHeight();
                if (heightDiff > dpToPx(context, 200)) { // if more than 200 dp, it's probably a keyboard...
                    agenciasContent.setVisibility(View.GONE);
                }
            }
        });
        mSearchItem.setQueryHint("Clave del Expediente");
        // Create a new thread inside your Actvity.
        Thread thread = new Thread() {

            @Override
            public void run() {
                // Block this thread for 2 seconds.
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    Log.d("THREAD_ERROR:","Thread Failed to Sleep");
                }
                // After sleep finished blocking, create a Runnable to run on the UI Thread.
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(mMap == null){
                            Toast.makeText(activity,"Los servicios de Google play necesitan actualizarse para utilizar esta funcionalidad.",Toast.LENGTH_LONG).show();
                            activity.finish();
                        }
                    }
                });
            }

        };
        // Don't forget to start the thread.
        thread.start();
    }

    public static float dpToPx(Context context, float valueInDp) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, valueInDp, metrics);
    }

    private void setupWindowAnimations() {
        if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
            Fade fade = new Fade();
            fade.setDuration(1000);
            getWindow().setEnterTransition(fade);
        }
    }

    private float getColorForPin(){
        float color;
        switch (indexColor){
            case 1:
                color = 86;
                indexColor = 2;
                break;
            case 2:
                color = 25;
                indexColor = 3;
                break;
            case 3:
                color = 39;
                indexColor = 4;
                break;
            case 4:
                color = 198;
                indexColor = 1;
                break;
            default:
                color = 86;
                indexColor = 2;
                break;
        }
        return color;
    }

    public void addPinsToMap(AgenciaDeExpediente agenciaDeExpediente){
        mMap.clear();
        mMap.setOnMarkerClickListener(this);
        Marker marker = mMap.addMarker(
            new MarkerOptions()
                    .title(agenciaDeExpediente.Edificio)
                    .icon(BitmapDescriptorFactory.defaultMarker(getColorForPin()))
                    .position(new LatLng(agenciaDeExpediente.getLatitud(), agenciaDeExpediente.getLongitud()))
        );
        marker.setTag(agenciaDeExpediente);
        CameraPosition cameraPosition = new CameraPosition.Builder().target(new LatLng(agenciaDeExpediente.getLatitud(), agenciaDeExpediente.getLongitud())).zoom(14).build();
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
        marker.showInfoWindow();
        onMarkerClick(marker);
    }

    @OnClick(R.id.toolbar_back_btn)
    public void onBackNavigation(){
        super.onBackPressed();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMapClickListener(this);
        mMap.setOnCameraMoveStartedListener(this);
        // For dropping a marker at a point on the Map
        LatLng fiscalia = new LatLng(21.880870, -102.282461);
        // For zooming automatically to the location of the marker
        CameraPosition cameraPosition = new CameraPosition.Builder().target(fiscalia).zoom(15).build();
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
    }

    @Override
    public void onGetAgenciaIntegradoraDeExpedienteSuccess(AgenciaDeExpediente agenciaDeExpediente) {
        processDialog.dismiss();
        if(agenciaDeExpediente != null) {
            agenciasContent.setVisibility(View.GONE);
            addPinsToMap(agenciaDeExpediente);
        }
        else{
            new MaterialDialog.Builder(this)
                    .content("Lo sentimos, No Contamos con la ubicación de su Expediente.")
                    .show();
        }
    }

    @Override
    public void onConecctionError() {
        processDialog.dismiss();
        new MaterialDialog.Builder(this)
                .content("Lo sentimos, a ocurrido un error, por favor verifique su conexión a Internet.")
                .show();
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        if(mMap==null){
            Toast.makeText(this,"Los servicios de Google play necesitan actualizarse para utilizar esta funcionalidad.",Toast.LENGTH_LONG).show();
            this.finish();
            return true;
        }
        new MaterialDialog.Builder(this)
                .content("Ingrese la Contraseña la cual le fue asignada al momento de recibir su denuncia.")
                .inputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)
                .input("Contraseña", "", new MaterialDialog.InputCallback() {
                    @Override
                    public void onInput(@NonNull MaterialDialog dialog, CharSequence input) {
                        // Do something
                        processDialog.show();
                        presenter.getAgenciaIntegradoraDeExpediente(mSearchItem.getQuery().toString(),input.toString());
                        mSearchItem.clearFocus();
                    }
                }).show();
        return true;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        return false;
    }

    /**
     * Show agency information when marked is clicked.
     * @param marker
     * @return
     */
    @Override
    public boolean onMarkerClick(Marker marker) {
        mSearchItem.clearFocus();
        rootLayout.requestFocus();
        AgenciaDeExpediente agenciaGlobal = (AgenciaDeExpediente) marker.getTag();
        View agenciaView;
        agenciesInLocation.removeAllViews();
        ExpansionLayoutCollection expansionLayoutCollection = new ExpansionLayoutCollection();
        int colorIndex = 1;
        agenciaView = getLayoutInflater().inflate(R.layout.row_view_agency_information,null);
        ExpansionHeader header = agenciaView.findViewById(R.id.expansionHeader);
        ExpansionLayout expansionLayout = agenciaView.findViewById(R.id.expansionLayout);
        ((TextView) agenciaView.findViewById(R.id.content_domicilio)).setText(agenciaGlobal.Domicilio);
        agenciaView.findViewById(R.id.numero_agencias_label).setVisibility(View.GONE);
        ((TextView) agenciaView.findViewById(R.id.content_horario)).setText(agenciaGlobal.getHorario());
        agenciaView.findViewById(R.id.content_num_agencias).setVisibility(View.GONE);
        ((TextView) agenciaView.findViewById(R.id.content_telefono)).setText("(449) 478 2800");//agenciaGlobal.no_telefonico);
        ((TextView) agenciaView.findViewById(R.id.title)).setText(agenciaGlobal.getNombre());
        expansionLayoutCollection.add(expansionLayout);
        switch (colorIndex){
            case 1:
                header.setBackgroundResource(R.drawable.shape_expand_layout_collapsed_1);
                expansionLayout.setBackgroundResource(R.drawable.shape_expand_layout_content_1);
                header.setTag(1);
                colorIndex=2;
                break;
            case 2:
                header.setBackgroundResource(R.drawable.shape_expand_layout_collapsed_2);
                expansionLayout.setBackgroundResource(R.drawable.shape_expand_layout_content_2);
                header.setTag(2);
                colorIndex=3;
                break;
            case 3:
                header.setBackgroundResource(R.drawable.shape_expand_layout_collapsed_3);
                expansionLayout.setBackgroundResource(R.drawable.shape_expand_layout_content_3);
                header.setTag(3);
                colorIndex=4;
                break;
            case 4:
                header.setBackgroundResource(R.drawable.shape_expand_layout_collapsed_4);
                expansionLayout.setBackgroundResource(R.drawable.shape_expand_layout_content_4);
                header.setTag(4);
                colorIndex=1;
                break;
            default:
                header.setBackgroundResource(R.drawable.shape_expand_layout_collapsed_1);
                expansionLayout.setBackgroundResource(R.drawable.shape_expand_layout_content_1);
                header.setTag(1);
                colorIndex=2;
                break;
        }
        this.expansionHeaders.add( header );
        expansionLayout.addListener(new ExpansionLayout.Listener() {
            @Override
            public void onExpansionChanged(ExpansionLayout expansionLayout, boolean expanded) {
                if(!expanded){
                    for( ExpansionHeader expansionHeader : expansionHeaders ){
                        if(expansionLayout.getParent().equals(expansionHeader.getParent())){
                            switch((int)expansionHeader.getTag()){
                                case 1:
                                    expansionHeader.setBackgroundResource(R.drawable.shape_expand_layout_collapsed_1);
                                    break;
                                case 2:
                                    expansionHeader.setBackgroundResource(R.drawable.shape_expand_layout_collapsed_2);
                                    break;
                                case 3:
                                    expansionHeader.setBackgroundResource(R.drawable.shape_expand_layout_collapsed_3);
                                    break;
                                case 4:
                                    expansionHeader.setBackgroundResource(R.drawable.shape_expand_layout_collapsed_4);
                                    break;
                                default:
                                    expansionHeader.setBackgroundResource(R.drawable.shape_expand_layout_collapsed_1);
                                    break;
                            }
                        }
                    }
                }
            }
        });
        expansionLayout.addIndicatorListener(new ExpansionLayout.IndicatorListener() {
            @Override
            public void onStartedExpand(ExpansionLayout expansionLayout, boolean willExpand) {
                if(willExpand){
                    for( ExpansionHeader expansionHeader : expansionHeaders ){
                        if(expansionLayout.getParent().equals(expansionHeader.getParent())){
                            switch((int)expansionHeader.getTag()){
                                case 1:
                                    expansionHeader.setBackgroundResource(R.drawable.shape_expand_layout_expanded_1);
                                    break;
                                case 2:
                                    expansionHeader.setBackgroundResource(R.drawable.shape_expand_layout_expanded_2);
                                    break;
                                case 3:
                                    expansionHeader.setBackgroundResource(R.drawable.shape_expand_layout_expanded_3);
                                    break;
                                case 4:
                                    expansionHeader.setBackgroundResource(R.drawable.shape_expand_layout_expanded_4);
                                    break;
                                default:
                                    expansionHeader.setBackgroundResource(R.drawable.shape_expand_layout_expanded_1);
                                    break;
                            }
                        }
                    }
                }
            }
        });
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams( ViewGroup.LayoutParams.MATCH_PARENT , ViewGroup.LayoutParams.WRAP_CONTENT);
        agenciesInLocation.addView(agenciaView,layoutParams);
        int paddingStartEnd = 30;
        int paddingTopBottom = 30;
        switch ( getDensityName(getApplicationContext()) ){
            case "xxhdpi":
                paddingStartEnd = 20;
                paddingTopBottom = 18;
                break;
            case "xhdpi":
                paddingStartEnd = 15;
                paddingTopBottom = 12;
                break;
            case "hdpi":
                paddingStartEnd = 10;
                paddingTopBottom = 8;
                break;
            case "mdpi":
                paddingStartEnd = 8;
                paddingTopBottom = 5;
                break;
            case "ldpi":
                paddingStartEnd = 5;
                paddingTopBottom = 2;
                break;
        }
        agenciaView.setPadding(paddingStartEnd,paddingTopBottom,paddingStartEnd,paddingTopBottom);
        agenciasContent.setVisibility(View.VISIBLE);
        expansionLayoutCollection.openOnlyOne(true);
        expansionLayout.expand(true);
        // Return false to indicate that we have not consumed the event and that we wish
        // for the default behavior to occur (which is for the camera to move such that the
        // marker is centered and for the marker's info window to open, if it has one).
        return false;
    }

    private static String getDensityName(Context context) {
        float density = context.getResources().getDisplayMetrics().density;
        if (density >= 4.0) {
            return "xxxhdpi";
        }
        if (density >= 3.0) {
            return "xxhdpi";
        }
        if (density >= 2.0) {
            return "xhdpi";
        }
        if (density >= 1.5) {
            return "hdpi";
        }
        if (density >= 1.0) {
            return "mdpi";
        }
        return "ldpi";
    }

    @Override
    public void onCameraMoveStarted(int reason) {
        if (reason == GoogleMap.OnCameraMoveStartedListener.REASON_GESTURE) {
            //The user gestured on the map.
            agenciasContent.setVisibility(View.GONE);
        }
    }

    @Override
    public void onMapClick(LatLng latLng) {
        agenciasContent.setVisibility(View.GONE);
    }
}
