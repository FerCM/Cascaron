package com.fiscaliageneralags.fiscalia.Models;

/**
 * Created by ERodriguezF on 09/03/2018.
 * @author ERodriguezF
 * @version 1.18
 */

public class SugerenciaAlFiscal
{
    public String nombre ;
    public String correo;
    public String sugerencia;
    public String asunto;
}